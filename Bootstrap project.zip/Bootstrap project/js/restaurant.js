var ob;
var bill;
function start(){
    ob=["IDLI","POORI","DOSA","VADA","CHOLE BATORE","TEA/COFEE","EXIT"]
    ob_price=[40,30,45,20,50,10,0];
    bill=0;

}
function myclick(num)
{
    document.getElementById("selected_list").innerHTML="YOU HAVE SELECTED = "+ob[num];
    index=num;
}
function order(){
    var quant=document.getElementById("qty").value;
    var price=ob_price[index]*parseInt(quant);
    bill+=price;
}
function mybill(){
    document.getElementById("bill").innerHTML="PLEASE PAY THE BILL ="+bill;
}